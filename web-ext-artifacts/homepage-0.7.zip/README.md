# Homepage
A html page that replaces the homepage of you web browser.
<p align="center">
  <img src="Example.png" alt="Homepage">
</p>

## Customization
You can change the links and the welcome name by changing them in the `index.html` file.
