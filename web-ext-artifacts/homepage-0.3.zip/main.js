setInterval(function() {
    var date = new Date();
    var hour = date.getHours();
    var min = date.getMinutes();
    document.getElementById("clock").innerHTML = hour.toLocaleString('en-US', {minimumIntegerDigits:2, useGrouping:false}) + ":" + min.toLocaleString('en-US', {minimumIntegerDigits:2, useGrouping:false})/* adding time to the div */
    console.log("Done!");
}, 1 * 1000);
